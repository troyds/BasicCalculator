﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Calculator
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int x = 10;
            int y = x;

            x = 3;
            Console.WriteLine(y);

        }
    }
}
